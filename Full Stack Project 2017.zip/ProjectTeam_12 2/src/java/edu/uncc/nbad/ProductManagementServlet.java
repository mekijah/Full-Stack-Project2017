/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uncc.nbad;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import murach.business.Product;
import murach.data.ProductTable;

/**
 *
 * @author KamyTeeq
 */
@WebServlet(name = "ProductManagementServlet", urlPatterns = {"/productManagement"})
public class ProductManagementServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProductManagementServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ProductManagementServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        String action = request.getParameter("action");
        

       
       if (action.equals("displayProducts")) {
           ArrayList<Product> products = (ArrayList<Product>) ProductTable.selectProducts();
            
          HttpSession session = request.getSession();
          session.setAttribute("products", products);
          getServletContext().getRequestDispatcher("/products.jsp").forward(request, response);
            

        } else if (action.equals("addProduct")){
            getServletContext().getRequestDispatcher("/products.jsp").forward(request, response);

        } else if (action.equals("displayProduct")){
            getServletContext().getRequestDispatcher("/product.jsp").forward(request, response); 
        } else if (action.equals("deleteProduct")){
            getServletContext().getRequestDispatcher("/confirmDelete.jsp").forward(request, response); 
       }
        else {
            try (PrintWriter out = response.getWriter()) {
            out.println("error! no action ! ");
            }
        }
       
        HttpSession session = request.getSession();
        ArrayList<Product> products = (ArrayList<Product>) ProductTable.selectProducts();
        session.setAttribute("products", products);
        

        String url = "/products.jsp";
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // processRequest(request, response);
       // The following sample code shows how one can save a User object in a file:

String action = request.getParameter("action");

if(action.equals("addProduct"))
{
    String code = request.getParameter("code");
    String desc = request.getParameter("description");
    String price = request.getParameter("price");
    Product prod = new Product();
    prod.setCode(code);
    prod.setDescription(desc);
    prod.setPrice(Double.parseDouble(price));

     ProductTable.insertProduct(prod);
   
          HttpSession session = request.getSession();
          session.setAttribute("products", prod);
          getServletContext().getRequestDispatcher("/products.jsp").forward(request, response);
           
    
}else if (action.equals("deleteProduct")){
    
    //Get the product code of product to be deleted from parameter
        String codeToDelete = request.getParameter("productCode");
        System.out.println("user wants to delete code: " + codeToDelete);

        //Get the session and file path of the products text file
        HttpSession session = request.getSession();

        //Get the product object we want to delete
        Product productToDelete = ProductTable.selectProduct(codeToDelete);

        //Tell ProductTable to delete that product
        ProductTable.deleteProduct(productToDelete);
        
        //Tell request we deleted a product
        request.setAttribute("deletedProduct", productToDelete);
        request.setAttribute("didDelete", true);
}
else if (action.equals("updateproduct")){
    String originalCode = request.getParameter("originalCode");
        System.out.println("In updateProduct method, user wants to update code: " + originalCode);

        //Get the product object we want to update
        Product productToUpdate = ProductTable.selectProduct(originalCode);

        //Get new values from request parameters
        String code = request.getParameter("code");
        String desc = request.getParameter("desc");
        double price = Double.parseDouble(request.getParameter("price"));

        //Update the product's fields
        productToUpdate.setCode(code);
        productToUpdate.setDescription(desc);
        productToUpdate.setPrice(price);

        //Tell ProductTable to update that product
        ProductTable.updateProduct(productToUpdate, originalCode);
    
}
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
