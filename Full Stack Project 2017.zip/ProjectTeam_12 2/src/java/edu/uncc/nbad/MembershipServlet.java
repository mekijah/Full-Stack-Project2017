/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uncc.nbad;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import murach.business.User;
import murach.data.UserTable;

/**
 *
 * @author KamyTeeq
 */
@WebServlet(name = "MembershipServlet", urlPatterns = {"/membership"})
public class MembershipServlet extends HttpServlet {

    private Object user;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MembershipServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MembershipServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>"); 
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     //   processRequest(request, response);
        
        String action = request.getParameter("action");
        
        if (action.equals("login")) {
            getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
        } else if (action.equals("signup")){
            getServletContext().getRequestDispatcher("/signup.jsp").forward(request, response); 
        }
        
        HttpSession session = request.getSession();
        //String path = getServletContext().getRealPath("/WEB-INF/users.txt");
        //Save all users onto an Arraylist 
        System.out.println("Membership Servlet: Getting list of all users");
        ArrayList<User> users = (ArrayList<User>) UserTable.getUsers();
        session.setAttribute("users", users);

        String url = "/login.jsp";
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }
    

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        
        
        if(action.equals("login"))
        {
            
            
            //fetch user info - the one trying to log in
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            // verify that they exist in the user databse
            // fetching all users in the database
            //String path = getServletContext().getRealPath("/WEB-INF/users.txt");
            System.out.println("Membership Servlet: Getting list of all users");
            ArrayList<User> users = (ArrayList<User>) UserTable.getUsers();
            
            // search if user list contains the user info
            
            for(User u:users)
            {
                if(u.getEmail().equals(username) && u.getPassword().equals(password))
                {
                    
                        /// we have a legit user with valid credentials
                        // so we need to log her in
                        HttpSession session = request.getSession();
                        session.setAttribute("user", u);
                        
                        //forward this user to products page
                         getServletContext().getRequestDispatcher("/products.jsp").forward(request, response); 
                   }
            }
            getServletContext().getRequestDispatcher("/signup.jsp").forward(request, response);
            
        }
        
        if(action.equals("signup"))
        {
            // fetching user (to be signed up)info
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String firstname = request.getParameter("firstname");
            String lastname = request.getParameter("lastname");
            String email = request.getParameter("email");
            
            // create new user object
            User newuser= new User();
            
            newuser.setEmail(email);
            newuser.setFirstName(firstname);
            newuser.setLastName(lastname);
            newuser.setPassword(password);
           
            
            // save the new user to the database
            //String path = getServletContext().getRealPath("/WEB-INF/users.txt");
           // UserIO.addRecord(newuser, path);
            HttpSession session = request.getSession();
            UserTable.addRecord((User) user);
            session.setAttribute("user", user);
            getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
