
package murach.data;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import murach.business.User;

public class UserTable {

    static String url = "jdbc:mysql://localhost:3306/store";
    static String username = "user";
    static String pswd = "123";

    //Load JDBC Driver
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }

    }

    public static void addRecord(User user) throws IOException {

        // User data we need to save  
        String firstname = user.getFirstName();
        String lastname = user.getLastName();
        String email = user.getEmail(); // email is the same as the username of the user 
        String password = user.getPassword();

        try {

            //Start connection
            Connection connect = DriverManager.getConnection(url, username, password);

            //Create statement we want to execute
            String statementToexecute = "INSERT INTO users (firstname, lastName, email, password) "
                    + "VALUES (?, ?, ?, ?)"; // Question marks as placeholders 
            PreparedStatement statement = connect.prepareStatement(statementToexecute);
            
                    // Define the question marks 
                    statement.setString(1, firstname);
                    statement.setString(2, lastname);
                    statement.setString(3, email);
                    statement.setString(4, password);
                    
            
            //Execute Query, using .executeUpdate()
            System.out.println(statement.executeUpdate());
            System.out.println("New user has been inserted into the database");

        } catch (SQLException exc) { 
            System.err.println("Exception is thrown");
            System.err.println(exc.getMessage());
        }

    }

    public static User getUser(String emailAddress) throws IOException {

        User result = null;

        try {

            //Start connection
            Connection connect = DriverManager.getConnection(url, username, pswd);

            //Create statement we want to execute
            String statementToexecute = "SELECT * FROM users WHERE email = ?"; // Question mark as placeholder
            PreparedStatement statement = connect.prepareStatement(statementToexecute);

            //Defining the placeholder
            statement.setString(1, emailAddress);

            //Execute Query, using .executeUpdate()
            ResultSet queryResult = statement.executeQuery();

            //Search all rows of the table using .next
            if (queryResult.next()) {

                    String firstName = queryResult.getString("firstName");
                    String lastName = queryResult.getString("lastName");
                    String email = queryResult.getString("email");
                    String password = queryResult.getString("password");

                System.out.println("Get User:Found this user: " + firstName + " " + lastName + " " + email);

                //Create new user object 
                result = new User(firstName, lastName, email, password);
            }
        } catch (SQLException exc) { 
            System.err.println("Exception was thrown");
            System.err.println(exc.getMessage());
        }

        return result;

    }

    public static ArrayList<User> getUsers() throws IOException {

        //Create Arraylist for User 
        ArrayList<User> userList = new ArrayList<>();

        try {
            
            //Start connection
            Connection connect = DriverManager.getConnection(url, username, pswd);
            String preparedSQL = "SELECT firstName, lastName, email FROM users";

            PreparedStatement statementToexecute = connect.prepareStatement(preparedSQL);

            //Get result
            ResultSet queryResults = statementToexecute.executeQuery();

            do {
                //Get the information for each user
                String firstName = queryResults.getString("firstName");
                String lastName = queryResults.getString("lastName");
                String email = queryResults.getString("email");

                System.out.println("Get Users: this product was found : " + firstName + " " + lastName + " " + email);

                //Create User object 
                User result = new User(firstName, lastName, email, null);

                //Add new product
                userList.add(result);
            } while (queryResults.next()); 
            
        } catch (SQLException exc) { 
            System.err.println("Exception is thrown");
            System.err.println(exc.getMessage());
        }
        return userList;
    }

    public static HashMap<String, User> getUsersMap() throws IOException {

        //Create hash-map
        HashMap<String, User> userMap = new HashMap<>();

        try {
            //Start connection
            Connection connect = DriverManager.getConnection(url, username, pswd);
            String statementToexecute = "SELECT firstName, lastName, email FROM users";

            PreparedStatement statement = connect.prepareStatement(statementToexecute);

            ResultSet queryResults = statement.executeQuery();

            do {

                String firstName = queryResults.getString("firstName");
                String lastName = queryResults.getString("lastName");
                String email = queryResults.getString("email");

                System.out.println("Get User Map: found this product: " + firstName + " " + lastName + " " + email);

                //Create User object 
                User result = new User(firstName, lastName, email, null);
                userMap.put(email, result);
                
            }while (queryResults.next());
            
        } catch (SQLException exc) { 
            System.err.println("Exception is thrown");
            System.err.println(exc.getMessage());
        }
        return userMap;
    }
}
