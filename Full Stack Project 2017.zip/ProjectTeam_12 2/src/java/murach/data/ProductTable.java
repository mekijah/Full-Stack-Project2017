package murach.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import murach.business.Product;


public class ProductTable {

    static String url = "jdbc:mysql://localhost:3306/store";
    static String username = "user";
    static String pswd = "123";
    //private static String originalCode;

	
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }

    }

    public static List<Product> selectProducts() {
                 List<Product> productList = new ArrayList<>();

        try {
            //Start connection
            Connection connect = DriverManager.getConnection(url, username, pswd);
            String statementToexecute = "SELECT * FROM products";
            PreparedStatement statement = connect.prepareStatement(statementToexecute);

            //Get result
            ResultSet productResults = statement.executeQuery();

            //Loop through the result
            while (productResults.next()) {

                    String code = productResults.getString("code");
                    String desc = productResults.getString("description");
                    Double price = productResults.getDouble("price");

                System.out.println("Select Products: Found the following product: " + code + " " + desc + " " + price);

                //Create a product object 
                Product found = new Product(code, desc, price);
                productList.add(found);
            }
        } catch (SQLException exc) {
            System.err.println("Exception is thrown");
            System.err.println(exc.getMessage());
        }
        //Return productList;
        return productList;
    }

    

    public static Product selectProduct(String productCode) {
                Product result = null;

        try {

            //Start connection
            Connection connect = DriverManager.getConnection(url, username, pswd);
            String statementToexecute = "SELECT * FROM products WHERE code =? ";
            PreparedStatement statement = connect.prepareStatement(statementToexecute);
            statement.setString(1, productCode); // Define the question mark 

            //Get result object
            ResultSet productResults = statement.executeQuery();

            if (productResults.next()) { // Get the info. of the product found 

                    String code = productResults.getString("code");
                    String desc= productResults.getString("description");
                    Double price = productResults.getDouble("price");

                System.out.println("Select Product: Found the following product : " + code + " " + desc + " " + price);

                result = new Product(code, desc, price);
            }
        } catch (SQLException exc) { 
            System.err.println("Exception is thrown");
            System.err.println(exc.getMessage());
        }
        return result;
    }

    public static boolean exists(String productCode) {
                boolean exist = false;

        try {

            //Start connection
            Connection connect = DriverManager.getConnection(url, username, pswd);
            String statementToexecute = "SELECT * FROM products WHERE code = ?";
            PreparedStatement statement = connect.prepareStatement(statementToexecute);

            statement.setString(1, productCode); // Define the question mark 

            //Get result
            ResultSet productResult = statement.executeQuery();

            if (productResult.next()) {
                exist = true;
            } else {
                return exist; 
            }

        } catch (SQLException exc) { 
            System.err.println("Exception is thrown");
            System.err.println(exc.getMessage());
        }
        
        return exist;
    }    
    
    private static void saveProducts(List<Product> products) {
                 for (Product product : products) {
                     
            String code = product.getCode();
            String desc = product.getDescription();
            Double price = product.getPrice();

            try {

                //Start connection
                Connection connect = DriverManager.getConnection(url, username, pswd);
                String statementToexecute = "INSERT INTO products (code, description, price) "  + "VALUES (?, ?, ?)";
                PreparedStatement statement = connect.prepareStatement(statementToexecute);
                
                // Define the question marks 
                statement.setString(1, code);
                statement.setString(2, desc);
                statement.setDouble(3, price);

                //Execute Query, using .executeUpdate()
                System.out.println(statement.executeUpdate());
                System.out.println("The following product was added to the list of products: " + code + " " + desc + " " + price);

            } catch (SQLException exc) { 
                System.err.println("Exception is thrown");
                System.err.println(exc.getMessage());
            }
        }
    }

    public static void insertProduct(Product product) {
        String code = product.getCode();
        String desc = product.getDescription();
        Double price = product.getPrice();

        try {

            //Start connection
            Connection connect = DriverManager.getConnection(url, username, pswd);
            String statementToexecute = "INSERT INTO products (code, description, price) " + "VALUES (?, ?, ?)";
            PreparedStatement statement = connect.prepareStatement(statementToexecute);

            //Define the question mark 
            statement.setString(1, code);
            statement.setString(2, desc);
            statement.setDouble(3, price);

            //Execute Query, using .executeUpdate()
            System.out.println(statement.executeUpdate());
            System.out.println("The following product was added to the list of products: " + code + " " + desc + " " + price);

        } catch (SQLException exc) { 
            System.err.println("Exception is thrown");
            System.err.println(exc.getMessage());
        }
    }

    public static void updateProduct(Product product, String originalCode) {

        String code = product.getCode();
        String desc = product.getDescription();
        Double price = product.getPrice();

        try {

            //Start connection
            Connection connect = DriverManager.getConnection(url, username, pswd);
            String statementToexecute = "UPDATE products SET " + " code = ?, " + " description = ?, "+ " price = ?" + "WHERE code = ?";
            PreparedStatement statement = connect.prepareStatement(statementToexecute);

            //Define the question marks 
            statement.setString(1, code);
            statement.setString(2, desc);
            statement.setDouble(3, price);
            statement.setString(4, originalCode);

            //Execute Query, using executeUpdate
            System.out.println(statement.executeUpdate());
            System.out.println("The following product was updated: " + code + " " + desc + " " + price);

        } catch (SQLException e) { 
            System.err.println("Exception is thrown");
            System.err.println(e.getMessage());
        }
    }

    public static void deleteProduct(Product product) {
            String code = product.getCode();
            String desc = product.getDescription();
            Double price = product.getPrice();

        try {

            //Start connection
            Connection connect = DriverManager.getConnection(url, username, pswd);
            String statementToexecute = "DELETE FROM products " + "WHERE code = ?";
            PreparedStatement statement = connect.prepareStatement(statementToexecute);
            statement.setString(1, code); // Define the question mark 

            //Execute Query, using .executeUpdate()
            System.out.println(statement.executeUpdate());
            System.out.println("Deleted the following product from the database: " + code + " " + desc + " " + price);

        } catch (SQLException exc) { 
            System.err.println("Exception is thrown");
            System.err.println(exc.getMessage());
        }
    }

    }    

